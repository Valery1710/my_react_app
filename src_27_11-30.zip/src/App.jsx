import React from 'react';
// import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { HashRouter, Routes, Route } from 'react-router-dom';
import ListProjects from './Components/ListProjects/ListProjects';
import CreateProject from './Components/CreateProject_1/CreateProject';
import CreateVacancy from './Components/CreateVacancy/CreateVacancy';

import UpdateProject from './Components/UpdateProject/UpdateProject';
import ProjectDetails from './Components/ProjectDetails/ProjectDetails';

function App() {
  return (
    <div>
      Task_1 my-app 1

      <HashRouter>
        <Routes>
          <Route path="/" element={<ListProjects />} />
          <Route path="/createproject" element={<CreateProject />} />
          <Route path="/createvacancy" element={<CreateVacancy />} />
          <Route path="/projectdetails" element={<ProjectDetails />} />
          <Route path="/my_react_app" element={<CreateProject />} />
          <Route path="*" element={<ListProjects />} />
          {/* <Route /> */}
        </Routes>
      </HashRouter>
    </div>
  );
}

export default App;
