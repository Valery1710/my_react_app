import { makeAutoObservable } from 'mobx';

class VacancyStore {
   //массив объектов в каждом объекте одтельный проект
  items = JSON.parse(localStorage.getItem('vacanciesStore')) ? JSON.parse(localStorage.getItem('vacanciesStore')) : [];
  constructor() {
    makeAutoObservable(this);
  }

  addItem(item) {
    console.log('addItem')
    this.items = JSON.parse(localStorage.getItem('vacanciesStore')) ? JSON.parse(localStorage.getItem('projectStore')) : [];

    if (this.items.some((el) => el.id === item.id)) //проверка уникльности id вакансии
      {
        console.log("Vacancy with this id already exists!")
      }else{
      const newVacancy = { id: Date.now(), ...item};
      this.items.push(newVacancy);
      localStorage.setItem('vacanciesStore', JSON.stringify(this.items));
    }
  }

  removeItem(id) {

    this.items = JSON.parse(localStorage.getItem('vacanciesStore'));
    this.items = this.items.filter((item) => item.id !== id);
    localStorage.setItem('vacanciesStore', JSON.stringify(this.items));
  }

  updateItem(item) {
    this.removeItem(item.id)
    this.addItem(item)
  }


}

const vacancyStore = new VacancieVacancyStoresStore();
export default vacanciesStore;
